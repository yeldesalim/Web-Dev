n = int(input())
sum = 0
while n > 0:
    sum += int(input())
    n -= 1
print(sum)