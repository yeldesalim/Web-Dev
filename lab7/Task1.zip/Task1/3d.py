x,d = map( str, input().split(" "))
cnt = 0
for s in x:
    if s == d:
        cnt +=1
print(cnt)