a,b = map(int,(input().split(" ")))
if ((a!=1 and b!=1) or (a==1 and b==1)):
    print("YES")
else:
    print("NO")