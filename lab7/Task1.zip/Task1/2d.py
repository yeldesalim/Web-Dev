n = int(input())
if (n>0): print(1)
if (n<0): print(-1)
if (n==0): print(0)