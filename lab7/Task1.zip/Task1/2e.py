a,b = map(int, input().split(" "))
if a ==b : print(0)
else: print( 1 if a > b else 2 )