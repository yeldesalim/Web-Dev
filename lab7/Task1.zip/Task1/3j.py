import math
arr = list(map(int, input().split()))
print(sum(arr))