if __name__ == '__main__':
    n = int(input())
    i = 0
    while i <= n-1:
        print(i*i)
        i +=1