x = input()
sum = 0
for y in x:
    sum += int(y)
print(sum)