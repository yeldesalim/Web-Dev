import math
a = float(input())
b = float(input())
c = math.sqrt(a**2+b**2)
print(c)