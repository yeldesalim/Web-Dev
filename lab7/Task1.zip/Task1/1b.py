num = int(input())
print("The next number for the number",num, "is", num+1)
print("The previous number for the number",num, "is", num-1)